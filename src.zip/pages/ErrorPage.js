import React, { Component } from "react";

export class ErrorPage extends Component {
  render() {
    return <div>404 error</div>;
  }
}

export default ErrorPage;
