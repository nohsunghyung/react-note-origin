import React, { Component } from "react";

export class LoadingBar extends Component {
  render() {
    return <div id="loading"></div>;
  }
}

export default LoadingBar;
